﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class Button3 : Form
    {
        public Button3()
        {
            InitializeComponent();
        }

        private void btnMensalista_Click(object sender, EventArgs e)
        {
            frmMensalista frmMensalista = new frmMensalista();
            frmMensalista.Show();
        }

        private void btnHorista_Click(object sender, EventArgs e)
        {
            frmHorista frmHorista = new frmHorista();
            frmHorista.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show ("Teste", "Mudei o Titulo",
                MessageBoxButtons.YesNo,MessageBoxIcon.Information);
        }
    }
}
