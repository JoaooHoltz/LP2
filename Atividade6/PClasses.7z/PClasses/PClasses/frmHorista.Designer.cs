﻿namespace PClasses
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInstaMensalista = new System.Windows.Forms.Button();
            this.txtData = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblDataEntradaEmpresa = new System.Windows.Forms.Label();
            this.lblSalarioMensal = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.lblNumeroHoras = new System.Windows.Forms.Label();
            this.txtFalta = new System.Windows.Forms.TextBox();
            this.lblDiasFalta = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnInstaMensalista
            // 
            this.btnInstaMensalista.Location = new System.Drawing.Point(501, 379);
            this.btnInstaMensalista.Name = "btnInstaMensalista";
            this.btnInstaMensalista.Size = new System.Drawing.Size(233, 103);
            this.btnInstaMensalista.TabIndex = 18;
            this.btnInstaMensalista.Text = "Instaciar Horista";
            this.btnInstaMensalista.UseVisualStyleBackColor = true;
            this.btnInstaMensalista.Click += new System.EventHandler(this.btnInstaMensalista_Click);
            // 
            // txtData
            // 
            this.txtData.Location = new System.Drawing.Point(401, 241);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(150, 20);
            this.txtData.TabIndex = 18;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(401, 148);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 16;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(401, 105);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(602, 20);
            this.txtNome.TabIndex = 15;
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(401, 64);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 14;
            // 
            // lblDataEntradaEmpresa
            // 
            this.lblDataEntradaEmpresa.AutoSize = true;
            this.lblDataEntradaEmpresa.Location = new System.Drawing.Point(245, 248);
            this.lblDataEntradaEmpresa.Name = "lblDataEntradaEmpresa";
            this.lblDataEntradaEmpresa.Size = new System.Drawing.Size(129, 13);
            this.lblDataEntradaEmpresa.TabIndex = 13;
            this.lblDataEntradaEmpresa.Text = "Data Entrada na Empresa";
            // 
            // lblSalarioMensal
            // 
            this.lblSalarioMensal.AutoSize = true;
            this.lblSalarioMensal.Location = new System.Drawing.Point(245, 155);
            this.lblSalarioMensal.Name = "lblSalarioMensal";
            this.lblSalarioMensal.Size = new System.Drawing.Size(83, 13);
            this.lblSalarioMensal.TabIndex = 12;
            this.lblSalarioMensal.Text = "Salário por Hora";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(245, 112);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(35, 13);
            this.lblNome.TabIndex = 11;
            this.lblNome.Text = "Nome";
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Location = new System.Drawing.Point(245, 71);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(52, 13);
            this.lblMatricula.TabIndex = 10;
            this.lblMatricula.Text = "Matrícula";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(401, 195);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(100, 20);
            this.txtHora.TabIndex = 17;
            // 
            // lblNumeroHoras
            // 
            this.lblNumeroHoras.AutoSize = true;
            this.lblNumeroHoras.Location = new System.Drawing.Point(245, 202);
            this.lblNumeroHoras.Name = "lblNumeroHoras";
            this.lblNumeroHoras.Size = new System.Drawing.Size(90, 13);
            this.lblNumeroHoras.TabIndex = 20;
            this.lblNumeroHoras.Text = "Número de Horas";
            // 
            // txtFalta
            // 
            this.txtFalta.Location = new System.Drawing.Point(401, 297);
            this.txtFalta.Name = "txtFalta";
            this.txtFalta.Size = new System.Drawing.Size(100, 20);
            this.txtFalta.TabIndex = 19;
            // 
            // lblDiasFalta
            // 
            this.lblDiasFalta.AutoSize = true;
            this.lblDiasFalta.Location = new System.Drawing.Point(245, 304);
            this.lblDiasFalta.Name = "lblDiasFalta";
            this.lblDiasFalta.Size = new System.Drawing.Size(69, 13);
            this.lblDiasFalta.TabIndex = 22;
            this.lblDiasFalta.Text = "Dias de Falta";
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1249, 602);
            this.Controls.Add(this.txtFalta);
            this.Controls.Add(this.lblDiasFalta);
            this.Controls.Add(this.txtHora);
            this.Controls.Add(this.lblNumeroHoras);
            this.Controls.Add(this.btnInstaMensalista);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblDataEntradaEmpresa);
            this.Controls.Add(this.lblSalarioMensal);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnInstaMensalista;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblDataEntradaEmpresa;
        private System.Windows.Forms.Label lblSalarioMensal;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label lblNumeroHoras;
        private System.Windows.Forms.TextBox txtFalta;
        private System.Windows.Forms.Label lblDiasFalta;
    }
}