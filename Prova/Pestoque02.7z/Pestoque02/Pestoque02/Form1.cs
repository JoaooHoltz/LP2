﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pestoque02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            int[,] vetorProdutos = new int[4, 4];
            int[,] vetorSemana = new int[4, 4];
            string auxiliar = " ";

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    string Produtos = Interaction.InputBox($"Total Entradas do Produtos: {i}","Semana: {j}");
                    if (Produtos > 0)
                    {
                        auxiliar += Produtos;
                    }
                    
                }
            }
        }

    }
}
